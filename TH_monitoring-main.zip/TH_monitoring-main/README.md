# TH_monitoring
This project demonstrates a simple yet effective approach to real-time environmental monitoring using Python, PySide6 for the graphical user interface (GUI), and MariaDB for data storage. 
